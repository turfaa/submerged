make clean
make
./bin/submerged
